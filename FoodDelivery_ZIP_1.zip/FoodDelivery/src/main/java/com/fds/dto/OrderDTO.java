package com.fds.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class OrderDTO {
    private int orderId;
    private LocalDateTime orderDate;
    private String orderStatus;
    private int customerId;
    private int restaurantId;
    private int deliveryDriverId;
}