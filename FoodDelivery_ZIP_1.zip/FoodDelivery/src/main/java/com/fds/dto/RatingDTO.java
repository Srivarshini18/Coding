package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RatingDTO {
    private int ratingId;
    private int orderId;
    private int restaurantId;
    private int rating;
    private String review;
}