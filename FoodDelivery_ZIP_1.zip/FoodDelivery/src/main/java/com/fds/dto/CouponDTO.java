package com.fds.dto;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CouponDTO {
    private int couponId;
    private String couponCode;
    private double discountAmount;
    private Date expiryDate;
}