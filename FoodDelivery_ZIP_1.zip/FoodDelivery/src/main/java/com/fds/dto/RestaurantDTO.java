package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RestaurantDTO {
    private int restaurantId;
    private String restaurantName;
    private String restaurantAddress;
    private long phnNum;
}