package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeliveryAddressDTO {
    private int addressId;
    private int customerId;
    private int restaurantId;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String postalCode;
}