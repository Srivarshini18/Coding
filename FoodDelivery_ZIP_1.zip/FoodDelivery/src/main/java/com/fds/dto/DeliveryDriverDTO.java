package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeliveryDriverDTO {
    private int driverId;
    private String driverName;
    private String driverPhone;
    private String driverVehicle;
}