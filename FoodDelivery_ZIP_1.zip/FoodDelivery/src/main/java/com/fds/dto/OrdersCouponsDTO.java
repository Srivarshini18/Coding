package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrdersCouponsDTO {
    private int id;
    private int orderId;
    private int couponId;
}