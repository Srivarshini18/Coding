package com.fds.dto;

import com.fds.entities.Customer;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CustomerDTO {
    private int customerId;
    private String customerName;
    private String customerEmail;
    private long phnNum;
	public CustomerDTO(Customer cust) {
		
		this.customerId =cust.getCustomerId();
		this.customerName = getCustomerName();
		this.customerEmail = getCustomerEmail();
		this.phnNum = getPhnNum();
	}
    
    
}