package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderItemDTO {
    private int orderItemId;
    private int orderId;
    private int itemId;
    private int quantity;
}