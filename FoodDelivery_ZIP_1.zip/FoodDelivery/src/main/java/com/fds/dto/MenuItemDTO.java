package com.fds.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MenuItemDTO {
    private int itemId;
    private String itemName;
    private String itemDescription;
    private double itemPrice;
    private int restaurantId;
}