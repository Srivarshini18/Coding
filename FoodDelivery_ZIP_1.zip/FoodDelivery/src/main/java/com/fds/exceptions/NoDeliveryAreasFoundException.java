package com.fds.exceptions;

public class NoDeliveryAreasFoundException extends RuntimeException {
	public NoDeliveryAreasFoundException(String message) {
        super(message);
	}
}
