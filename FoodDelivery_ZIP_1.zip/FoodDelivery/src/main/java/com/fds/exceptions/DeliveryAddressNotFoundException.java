package com.fds.exceptions;

public class DeliveryAddressNotFoundException extends RuntimeException {
    public DeliveryAddressNotFoundException(String message) {
        super(message);
    }
}
