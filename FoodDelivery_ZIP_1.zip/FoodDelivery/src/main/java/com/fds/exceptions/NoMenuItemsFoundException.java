package com.fds.exceptions;

public class NoMenuItemsFoundException extends RuntimeException {
    public NoMenuItemsFoundException(String message) {
        super(message);
    }
}
