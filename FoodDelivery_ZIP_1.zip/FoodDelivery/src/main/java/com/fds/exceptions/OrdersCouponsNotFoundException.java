package com.fds.exceptions;

public class OrdersCouponsNotFoundException extends RuntimeException {
    public OrdersCouponsNotFoundException(String message) {
        super(message);
    }
}
