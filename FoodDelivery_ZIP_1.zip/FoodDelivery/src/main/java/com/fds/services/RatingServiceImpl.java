package com.fds.services;

import com.fds.dto.RatingDTO;
import com.fds.entities.Rating;
import com.fds.exceptions.RatingNotFoundException;
import com.fds.mapper.RatingMapper;
import com.fds.repositories.RatingRepository;
import com.fds.services.IRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RatingServiceImpl implements IRatingService {

    @Autowired
    private RatingRepository ratingRepository;

    @Override
    public List<RatingDTO> getAllRatings() {
        return ratingRepository.findAll().stream()
                .map(RatingMapper.INSTANCE::toRatingDTO)
                .collect(Collectors.toList());
    }

    @Override
    public RatingDTO getRatingById(int ratingId) {
        return ratingRepository.findById(ratingId)
                .map(RatingMapper.INSTANCE::toRatingDTO)
                .orElseThrow(() -> new RatingNotFoundException("Rating not found with id: " + ratingId));
    }

    @Override
    public RatingDTO createRating(RatingDTO ratingDTO) {
        Rating rating = RatingMapper.INSTANCE.toRating(ratingDTO);
        Rating savedRating = ratingRepository.save(rating);
        return RatingMapper.INSTANCE.toRatingDTO(savedRating);
    }

    @Override
    public RatingDTO updateRating(int ratingId, RatingDTO ratingDTO) {
        if (ratingRepository.existsById(ratingId)) {
            Rating rating = RatingMapper.INSTANCE.toRating(ratingDTO);
            rating.setRatingId(ratingId);
            Rating updatedRating = ratingRepository.save(rating);
            return RatingMapper.INSTANCE.toRatingDTO(updatedRating);
        }
        throw new RatingNotFoundException("Rating not found with id: " + ratingId);
    }

    @Override
    public void deleteRating(int ratingId) {
        if (ratingRepository.existsById(ratingId)) {
            ratingRepository.deleteById(ratingId);
        } else {
            throw new RatingNotFoundException("Rating not found with id: " + ratingId);
        }
    }
}