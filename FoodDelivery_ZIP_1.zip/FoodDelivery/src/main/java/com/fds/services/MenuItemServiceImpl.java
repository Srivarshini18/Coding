package com.fds.services;

import com.fds.dto.MenuItemDTO;
import com.fds.entities.MenuItem;
import com.fds.exceptions.MenuItemNotFoundException;
import com.fds.mapper.MenuItemMapper;
import com.fds.repositories.MenuItemRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MenuItemServiceImpl implements IMenuItemService {

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Override
    public List<MenuItemDTO> getAllMenuItems() {
        return menuItemRepository.findAll().stream()
                .map(MenuItemMapper.INSTANCE::toMenuItemDTO)
                .collect(Collectors.toList());
    }

    @Override
    public MenuItemDTO getMenuItemById(int itemId) {
        return menuItemRepository.findById(itemId)
                .map(MenuItemMapper.INSTANCE::toMenuItemDTO)
                .orElseThrow(() -> new MenuItemNotFoundException("Menu item not found with id: " + itemId));
    }

    @Override
    public MenuItemDTO createMenuItem(MenuItemDTO menuItemDTO) {
        MenuItem menuItem = MenuItemMapper.INSTANCE.toMenuItem(menuItemDTO);
        MenuItem savedMenuItem = menuItemRepository.save(menuItem);
        return MenuItemMapper.INSTANCE.toMenuItemDTO(savedMenuItem);
    }

    @Override
    public MenuItemDTO updateMenuItem(int itemId, MenuItemDTO menuItemDTO) {
        if (menuItemRepository.existsById(itemId)) {
            MenuItem menuItem = MenuItemMapper.INSTANCE.toMenuItem(menuItemDTO);
            menuItem.setItemId(itemId);
            MenuItem updatedMenuItem = menuItemRepository.save(menuItem);
            return MenuItemMapper.INSTANCE.toMenuItemDTO(updatedMenuItem);
        }
        throw new MenuItemNotFoundException("Menu item not found with id: " + itemId);
    }

    @Override
    public void deleteMenuItem(int itemId) {
        if (menuItemRepository.existsById(itemId)) {
            menuItemRepository.deleteById(itemId);
        } else {
            throw new MenuItemNotFoundException("Menu item not found with id: " + itemId);
        }
    }
}