package com.fds.services;

import com.fds.dto.CouponDTO;
import java.util.List;

public interface ICouponService {
    List<CouponDTO> getAllCoupons();
    CouponDTO getCouponById(int couponId);
    CouponDTO createCoupon(CouponDTO couponDTO);
    CouponDTO updateCoupon(int couponId, CouponDTO couponDTO);
    void deleteCoupon(int couponId);
}
