package com.fds.services;

import com.fds.dto.OrderItemDTO;
import com.fds.entities.OrderItem;
import com.fds.exceptions.OrderItemNotFoundException;
import com.fds.mapper.OrderItemMapper;
import com.fds.repositories.OrderItemRepository;
import com.fds.services.IOrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderItemServiceImpl implements IOrderItemService {

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Override
    public List<OrderItemDTO> getAllOrderItems() {
        return orderItemRepository.findAll().stream()
                .map(OrderItemMapper.INSTANCE::toOrderItemDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderItemDTO getOrderItemById(int orderItemId) {
        return orderItemRepository.findById(orderItemId)
                .map(OrderItemMapper.INSTANCE::toOrderItemDTO)
                .orElseThrow(() -> new OrderItemNotFoundException("Order item not found with id: " + orderItemId));
    }

    @Override
    public OrderItemDTO createOrderItem(OrderItemDTO orderItemDTO) {
        OrderItem orderItem = OrderItemMapper.INSTANCE.toOrderItem(orderItemDTO);
        OrderItem savedOrderItem = orderItemRepository.save(orderItem);
        return OrderItemMapper.INSTANCE.toOrderItemDTO(savedOrderItem);
    }

    @Override
    public OrderItemDTO updateOrderItem(int orderItemId, OrderItemDTO orderItemDTO) {
        if (orderItemRepository.existsById(orderItemId)) {
            OrderItem orderItem = OrderItemMapper.INSTANCE.toOrderItem(orderItemDTO);
            orderItem.setOrderItemId(orderItemId);
            OrderItem updatedOrderItem = orderItemRepository.save(orderItem);
            return OrderItemMapper.INSTANCE.toOrderItemDTO(updatedOrderItem);
        }
        throw new OrderItemNotFoundException("Order item not found with id: " + orderItemId);
    }

    @Override
    public void deleteOrderItem(int orderItemId) {
        if (orderItemRepository.existsById(orderItemId)) {
            orderItemRepository.deleteById(orderItemId);
        } else {
            throw new OrderItemNotFoundException("Order item not found with id: " + orderItemId);
        }
    }
}