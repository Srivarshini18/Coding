package com.fds.services;

import com.fds.dto.OrdersCouponsDTO;
import java.util.List;

public interface IOrdersCouponsService {
    List<OrdersCouponsDTO> getAllOrdersCoupons();
    OrdersCouponsDTO getOrdersCouponsById(int id);
    OrdersCouponsDTO createOrdersCoupons(OrdersCouponsDTO ordersCouponsDTO);
    OrdersCouponsDTO updateOrdersCoupons(int id, OrdersCouponsDTO ordersCouponsDTO);
    void deleteOrdersCoupons(int id);
}