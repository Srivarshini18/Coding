package com.fds.services;

import java.util.List;

import com.fds.dto.DeliveryDriverDTO;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.Order;

public interface IDeliveryDriverService {
	
	List<DeliveryDriverDTO> getAllDeliveryDrivers();
	DeliveryDriverDTO getDeliveryDriverById(int driverId);
	DeliveryDriverDTO createDeliveryDriver(DeliveryDriverDTO deliveryDriverDTO);
	DeliveryDriverDTO updateDeliveryDriver(int driverId, DeliveryDriverDTO deliveryDriverDTO); 
	void deleteDeliveryDriver(int driverId); 
	void assignDriverToOrder(int orderId, int driverId) ;
	void updateDriverLocation(int driverId, DeliveryAddress deliveryAddress);
	List<Order> getOrdersByDriverId(int driverId);
 
}