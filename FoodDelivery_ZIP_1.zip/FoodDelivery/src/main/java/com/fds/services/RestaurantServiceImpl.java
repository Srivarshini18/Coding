package com.fds.services;

import com.fds.dto.*;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.Rating;
import com.fds.entities.Restaurant;
import com.fds.exceptions.NoDeliveryAreasFoundException;
import com.fds.exceptions.NoMenuItemsFoundException;
import com.fds.exceptions.NoReviewsFoundException;
import com.fds.exceptions.RestaurantNotFoundException;
import com.fds.mapper.MenuItemMapper;
import com.fds.mapper.RestaurantMapper;
import com.fds.repositories.RestaurantRepository;
import com.fds.services.IRestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RestaurantServiceImpl implements IRestaurantService {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Override
    public List<RestaurantDTO> getAllRestaurants() {
        return restaurantRepository.findAll().stream()
                .map(RestaurantMapper.INSTANCE::toRestaurantDTO)
                .collect(Collectors.toList());
    }

    @Override
    public RestaurantDTO getRestaurantById(int restaurantId) {
        return restaurantRepository.findById(restaurantId)
                .map(RestaurantMapper.INSTANCE::toRestaurantDTO)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId));
    }

    @Override
    public RestaurantDTO createRestaurant(RestaurantDTO restaurantDTO) {
        Restaurant restaurant = RestaurantMapper.INSTANCE.toRestaurant(restaurantDTO);
        Restaurant savedRestaurant = restaurantRepository.save(restaurant);
        return RestaurantMapper.INSTANCE.toRestaurantDTO(savedRestaurant);
    }

    @Override
    public RestaurantDTO updateRestaurant(int restaurantId, RestaurantDTO restaurantDTO) {
        if (restaurantRepository.existsById(restaurantId)) {
            Restaurant restaurant = RestaurantMapper.INSTANCE.toRestaurant(restaurantDTO);
            restaurant.setRestaurantId(restaurantId);
            Restaurant updatedRestaurant = restaurantRepository.save(restaurant);
            return RestaurantMapper.INSTANCE.toRestaurantDTO(updatedRestaurant);
        }
        throw new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId);
    }

    @Override
    public void deleteRestaurant(int restaurantId) {
        if (restaurantRepository.existsById(restaurantId)) {
            restaurantRepository.deleteById(restaurantId);
        } else {
            throw new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId);
        }
    }

    @Override
    public List<MenuItemDTO> getMenuItemsByRestaurant(int restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId));
        List<MenuItemDTO> menuItems = restaurant.getMenuItems().stream()
                .map(MenuItemMapper.INSTANCE::toMenuItemDTO)
                .collect(Collectors.toList());
        if (menuItems.isEmpty()) {
            throw new NoMenuItemsFoundException("No menu items found for restaurant with id: " + restaurantId);
        }
        return menuItems;
    }

    @Override
    public List<Rating> getReviewsByRestaurant(int restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId));
        List<Rating> ratings = restaurant.getRatings();
        if (ratings.isEmpty()) {
            throw new NoReviewsFoundException("No reviews found for restaurant with id: " + restaurantId);
        }
        return ratings;
    }

    @Override
    public List<DeliveryAddress> getDeliveryAreasByRestaurant(int restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with id: " + restaurantId));
        List<DeliveryAddress> deliveryAddresses = restaurant.getDeliveryAddresses();
        if (deliveryAddresses.isEmpty()) {
            throw new NoDeliveryAreasFoundException("No delivery areas found for restaurant with id: " + restaurantId);
        }
        return deliveryAddresses;
    }
}
