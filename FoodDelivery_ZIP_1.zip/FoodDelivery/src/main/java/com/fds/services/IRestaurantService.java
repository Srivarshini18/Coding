package com.fds.services;


import com.fds.dto.*;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.Rating;
import java.util.List;

public interface IRestaurantService {
    List<RestaurantDTO> getAllRestaurants();
    RestaurantDTO getRestaurantById(int restaurantId);
    RestaurantDTO createRestaurant(RestaurantDTO restaurantDTO);
    RestaurantDTO updateRestaurant(int restaurantId, RestaurantDTO restaurantDTO);
    void deleteRestaurant(int restaurantId);
    List<MenuItemDTO> getMenuItemsByRestaurant(int restaurantId);
    List<Rating> getReviewsByRestaurant(int restaurantId);
    List<DeliveryAddress> getDeliveryAreasByRestaurant(int restaurantId);
}

