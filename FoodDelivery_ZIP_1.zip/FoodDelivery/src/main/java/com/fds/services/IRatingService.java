package com.fds.services;

import com.fds.dto.RatingDTO;
import java.util.List;

public interface IRatingService {
    List<RatingDTO> getAllRatings();
    RatingDTO getRatingById(int ratingId);
    RatingDTO createRating(RatingDTO ratingDTO);
    RatingDTO updateRating(int ratingId, RatingDTO ratingDTO);
    void deleteRating(int ratingId);
}