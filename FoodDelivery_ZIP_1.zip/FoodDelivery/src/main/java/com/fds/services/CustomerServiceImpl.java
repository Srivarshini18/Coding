package com.fds.services;

import com.fds.dto.CustomerDTO;
import com.fds.dto.OrderDTO;
import com.fds.entities.Customer;
import com.fds.entities.Rating;
import com.fds.exceptions.CustomerNotFoundException;
import com.fds.exceptions.NoOrdersFoundException;
import com.fds.exceptions.NoReviewsFoundException;
import com.fds.mapper.CustomerMapper;
import com.fds.mapper.OrderMapper;
import com.fds.repositories.CustomerRepository;
import com.fds.services.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements ICustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(CustomerMapper.INSTANCE::toCustomerDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<CustomerDTO> getCustomerById(int customerId) {
        return Optional.of(customerRepository.findById(customerId)
                .map(CustomerMapper.INSTANCE::toCustomerDTO)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + customerId)));
    }

    @Override
    public CustomerDTO createCustomer(CustomerDTO customerDTO) {
        Customer customer = CustomerMapper.INSTANCE.toCustomer(customerDTO);
        Customer savedCustomer = customerRepository.save(customer);
        return CustomerMapper.INSTANCE.toCustomerDTO(savedCustomer);
    }

    @Override
    public CustomerDTO updateCustomer(int customerId, CustomerDTO customerDTO) {
        if (customerRepository.existsById(customerId)) {
            Customer customer = CustomerMapper.INSTANCE.toCustomer(customerDTO);
            customer.setCustomerId(customerId);
            Customer updatedCustomer = customerRepository.save(customer);
            return CustomerMapper.INSTANCE.toCustomerDTO(updatedCustomer);
        }
        throw new CustomerNotFoundException("Customer not found with id: " + customerId);
    }

    @Override
    public void deleteCustomer(int customerId) {
        if (customerRepository.existsById(customerId)) {
            customerRepository.deleteById(customerId);
        } else {
            throw new CustomerNotFoundException("Customer not found with id: " + customerId);
        }
    }

    @Override
    public List<OrderDTO> getOrdersByCustomer(int customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + customerId));
        List<OrderDTO> orders = customer.getOrders().stream()
                .map(OrderMapper.INSTANCE::toOrderDTO)
                .collect(Collectors.toList());
        if (orders.isEmpty()) {
            throw new NoOrdersFoundException("Customer has not placed any orders.");
        }
        return orders;
    }

    @Override
    public List<Rating> getReviewsByCustomer(int customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + customerId));
        List<Rating> ratings = customer.getRatings();
        if (ratings.isEmpty()) {
            throw new NoReviewsFoundException("No reviews found for customer with id: " + customerId);
        }
        return ratings;
    }
}
