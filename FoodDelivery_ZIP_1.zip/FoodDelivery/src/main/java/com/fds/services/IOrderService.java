package com.fds.services;

import java.util.List;

import com.fds.dto.OrderDTO;

public interface IOrderService {
    List<OrderDTO> getAllOrders();
    OrderDTO getOrderById(int orderId);
    OrderDTO createOrder(OrderDTO orderDTO);
    OrderDTO updateOrder(int orderId, OrderDTO orderDTO);
    OrderDTO assignDriver(int orderId, int driverId);
    void deleteOrder(int orderId);
}