package com.fds.services;

import com.fds.dto.OrderItemDTO;
import java.util.List;

public interface IOrderItemService {
    List<OrderItemDTO> getAllOrderItems();
    OrderItemDTO getOrderItemById(int orderItemId);
    OrderItemDTO createOrderItem(OrderItemDTO orderItemDTO);
    OrderItemDTO updateOrderItem(int orderItemId, OrderItemDTO orderItemDTO);
    void deleteOrderItem(int orderItemId);
}