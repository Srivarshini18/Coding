package com.fds.services;

import java.util.List;
import java.util.Optional;

import com.fds.dto.CustomerDTO;
import com.fds.dto.OrderDTO;
import com.fds.entities.Rating;
//import com.fds.entities.Customer;

public interface ICustomerService {
	List<CustomerDTO> getAllCustomers();
    Optional<CustomerDTO> getCustomerById(int customerId);
    CustomerDTO createCustomer(CustomerDTO customerDTO);
    CustomerDTO updateCustomer(int customerId, CustomerDTO customerDTO);
    void deleteCustomer(int customerId);
    List<OrderDTO> getOrdersByCustomer(int customerId);
    List<Rating> getReviewsByCustomer(int customerId);
	    
}