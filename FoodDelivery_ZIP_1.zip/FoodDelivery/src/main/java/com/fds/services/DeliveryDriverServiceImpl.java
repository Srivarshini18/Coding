package com.fds.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fds.dto.DeliveryDriverDTO;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.DeliveryDriver;
import com.fds.entities.Order;
import com.fds.exceptions.DeliveryDriverNotFoundException;
import com.fds.exceptions.OrderNotFoundException;
import com.fds.exceptions.ResourceNotFoundException;
import com.fds.mapper.DeliveryDriverMapper;
import com.fds.repositories.DeliveryDriverRepository;
import com.fds.repositories.OrderRepository;

@Service
public class DeliveryDriverServiceImpl implements IDeliveryDriverService {

    @Autowired
    private DeliveryDriverRepository deliveryDriverRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public List<DeliveryDriverDTO> getAllDeliveryDrivers() {
        return deliveryDriverRepository.findAll().stream()
                .map(DeliveryDriverMapper.INSTANCE::toDeliveryDriverDTO)
                .collect(Collectors.toList());
    }

    @Override
    public DeliveryDriverDTO getDeliveryDriverById(int driverId) {
        DeliveryDriver deliveryDriver = deliveryDriverRepository.findById(driverId)
                .orElseThrow(() -> new DeliveryDriverNotFoundException("Driver not found with id: " + driverId));
        return DeliveryDriverMapper.INSTANCE.toDeliveryDriverDTO(deliveryDriver);
    }

    @Override
    public DeliveryDriverDTO createDeliveryDriver(DeliveryDriverDTO deliveryDriverDTO) {
        DeliveryDriver deliveryDriver = DeliveryDriverMapper.INSTANCE.toDeliveryDriver(deliveryDriverDTO);
        DeliveryDriver savedDeliveryDriver = deliveryDriverRepository.save(deliveryDriver);
        return DeliveryDriverMapper.INSTANCE.toDeliveryDriverDTO(savedDeliveryDriver);
    }

    @Override
    public DeliveryDriverDTO updateDeliveryDriver(int driverId, DeliveryDriverDTO deliveryDriverDTO) {
        if (deliveryDriverRepository.existsById(driverId)) {
            DeliveryDriver deliveryDriver = DeliveryDriverMapper.INSTANCE.toDeliveryDriver(deliveryDriverDTO);
            deliveryDriver.setDriverId(driverId);
            DeliveryDriver updatedDeliveryDriver = deliveryDriverRepository.save(deliveryDriver);
            return DeliveryDriverMapper.INSTANCE.toDeliveryDriverDTO(updatedDeliveryDriver);
        }
        throw new DeliveryDriverNotFoundException("Driver not found with id: " + driverId);
    }

    @Override
    public void deleteDeliveryDriver(int driverId) {
        if (deliveryDriverRepository.existsById(driverId)) {
            deliveryDriverRepository.deleteById(driverId);
        } else {
            throw new DeliveryDriverNotFoundException("Driver not found with id: " + driverId);
        }
    }

    @Override
    public void assignDriverToOrder(int orderId, int driverId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        DeliveryDriver driver = deliveryDriverRepository.findById(driverId)
                .orElseThrow(() -> new DeliveryDriverNotFoundException("Driver not found with id: " + driverId));
        order.setDeliveryDriver(driver);
        orderRepository.save(order);
    }

    @Override
    public void updateDriverLocation(int driverId, DeliveryAddress deliveryAddress) {
        DeliveryDriver driver = deliveryDriverRepository.findById(driverId)
                .orElseThrow(() -> new DeliveryDriverNotFoundException("Driver not found with id: " + driverId));
        
        // Find the orders assigned to the driver and update their delivery address
        List<Order> orders = orderRepository.findByDeliveryDriver(driver);
        for (Order order : orders) {
            order.setDeliveryAddress(deliveryAddress);
            orderRepository.save(order);
        }
    }

    @Override
    public List<Order> getOrdersByDriverId(int driverId) {
        DeliveryDriver driver = deliveryDriverRepository.findById(driverId)
                .orElseThrow(() -> new DeliveryDriverNotFoundException("Driver not found with id: " + driverId));
        return driver.getOrders();
    }
}


