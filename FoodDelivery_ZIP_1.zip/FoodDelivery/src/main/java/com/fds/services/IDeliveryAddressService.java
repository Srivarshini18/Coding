package com.fds.services;

import com.fds.dto.DeliveryAddressDTO;
import java.util.List;

public interface IDeliveryAddressService {
    List<DeliveryAddressDTO> getAllDeliveryAddresses();
    DeliveryAddressDTO getDeliveryAddressById(int addressId);
    DeliveryAddressDTO createDeliveryAddress(DeliveryAddressDTO deliveryAddressDTO);
    DeliveryAddressDTO updateDeliveryAddress(int addressId, DeliveryAddressDTO deliveryAddressDTO);
    void deleteDeliveryAddress(int addressId);
}