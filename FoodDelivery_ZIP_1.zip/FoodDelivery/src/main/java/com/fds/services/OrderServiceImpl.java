package com.fds.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fds.dto.OrderDTO;
import com.fds.entities.DeliveryDriver;
import com.fds.entities.Order;
import com.fds.exceptions.DeliveryDriverNotFoundException;
import com.fds.exceptions.OrderNotFoundException;
import com.fds.mapper.OrderMapper;
import com.fds.repositories.DeliveryDriverRepository;
import com.fds.repositories.OrderRepository;

@Service
public class OrderServiceImpl implements IOrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private DeliveryDriverRepository driverRepository;

    @Override
    public List<OrderDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(OrderMapper.INSTANCE::toOrderDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO getOrderById(int orderId) {
        return orderRepository.findById(orderId)
                .map(OrderMapper.INSTANCE::toOrderDTO)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
    }

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        Order order = OrderMapper.INSTANCE.toOrder(orderDTO);
        Order savedOrder = orderRepository.save(order);
        return OrderMapper.INSTANCE.toOrderDTO(savedOrder);
    }

    @Override
    public OrderDTO updateOrder(int orderId, OrderDTO orderDTO) {
        if (orderRepository.existsById(orderId)) {
            Order order = OrderMapper.INSTANCE.toOrder(orderDTO);
            order.setOrderId(orderId);
            Order updatedOrder = orderRepository.save(order);
            return OrderMapper.INSTANCE.toOrderDTO(updatedOrder);
        }
        throw new OrderNotFoundException("Order not found with id: " + orderId);
    }

    @Override
    public OrderDTO assignDriver(int orderId, int driverId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        DeliveryDriver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new DeliveryDriverNotFoundException("Driver not found with id: " + driverId));
        order.setDeliveryDriver(driver);
        order.setOrderStatus("ASSIGNED");
        Order updatedOrder = orderRepository.save(order);
        return OrderMapper.INSTANCE.toOrderDTO(updatedOrder);
    }

    @Override
    public void deleteOrder(int orderId) {
        if (orderRepository.existsById(orderId)) {
            orderRepository.deleteById(orderId);
        } else {
            throw new OrderNotFoundException("Order not found with id: " + orderId);
        }
    }
}