package com.fds.services;

import com.fds.dto.OrdersCouponsDTO;
import com.fds.entities.OrdersCoupons;
import com.fds.exceptions.OrdersCouponsNotFoundException;
import com.fds.mapper.OrdersCouponsMapper;
import com.fds.repositories.OrdersCouponsRepository;
import com.fds.services.IOrdersCouponsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrdersCouponsServiceImpl implements IOrdersCouponsService {

    @Autowired
    private OrdersCouponsRepository ordersCouponsRepository;

    @Override
    public List<OrdersCouponsDTO> getAllOrdersCoupons() {
        return ordersCouponsRepository.findAll().stream()
                .map(OrdersCouponsMapper.INSTANCE::toOrdersCouponsDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrdersCouponsDTO getOrdersCouponsById(int id) {
        return ordersCouponsRepository.findById(id)
                .map(OrdersCouponsMapper.INSTANCE::toOrdersCouponsDTO)
                .orElseThrow(() -> new OrdersCouponsNotFoundException("OrdersCoupons not found with id: " + id));
    }

    @Override
    public OrdersCouponsDTO createOrdersCoupons(OrdersCouponsDTO ordersCouponsDTO) {
        OrdersCoupons ordersCoupons = OrdersCouponsMapper.INSTANCE.toOrdersCoupons(ordersCouponsDTO);
        OrdersCoupons savedOrdersCoupons = ordersCouponsRepository.save(ordersCoupons);
        return OrdersCouponsMapper.INSTANCE.toOrdersCouponsDTO(savedOrdersCoupons);
    }

    @Override
    public OrdersCouponsDTO updateOrdersCoupons(int id, OrdersCouponsDTO ordersCouponsDTO) {
        if (ordersCouponsRepository.existsById(id)) {
            OrdersCoupons ordersCoupons = OrdersCouponsMapper.INSTANCE.toOrdersCoupons(ordersCouponsDTO);
            ordersCoupons.setId(id);
            OrdersCoupons updatedOrdersCoupons = ordersCouponsRepository.save(ordersCoupons);
            return OrdersCouponsMapper.INSTANCE.toOrdersCouponsDTO(updatedOrdersCoupons);
        }
        throw new OrdersCouponsNotFoundException("OrdersCoupons not found with id: " + id);
    }

    @Override
    public void deleteOrdersCoupons(int id) {
        if (ordersCouponsRepository.existsById(id)) {
            ordersCouponsRepository.deleteById(id);
        } else {
            throw new OrdersCouponsNotFoundException("OrdersCoupons not found with id: " + id);
        }
    }
}