package com.fds.services;

import com.fds.dto.DeliveryAddressDTO;
import com.fds.entities.DeliveryAddress;
import com.fds.exceptions.DeliveryAddressNotFoundException;
import com.fds.mapper.DeliveryAddressMapper;
import com.fds.repositories.DeliveryAddressRepository;
import com.fds.services.IDeliveryAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DeliveryAddressServiceImpl implements IDeliveryAddressService {

    @Autowired
    private DeliveryAddressRepository deliveryAddressRepository;

    @Override
    public List<DeliveryAddressDTO> getAllDeliveryAddresses() {
        return deliveryAddressRepository.findAll().stream()
                .map(DeliveryAddressMapper.INSTANCE::toDeliveryAddressDTO)
                .collect(Collectors.toList());
    }

    @Override
    public DeliveryAddressDTO getDeliveryAddressById(int addressId) {
        return deliveryAddressRepository.findById(addressId)
                .map(DeliveryAddressMapper.INSTANCE::toDeliveryAddressDTO)
                .orElseThrow(() -> new DeliveryAddressNotFoundException("Delivery address not found with id: " + addressId));
    }

    @Override
    public DeliveryAddressDTO createDeliveryAddress(DeliveryAddressDTO deliveryAddressDTO) {
        DeliveryAddress deliveryAddress = DeliveryAddressMapper.INSTANCE.toDeliveryAddress(deliveryAddressDTO);
        DeliveryAddress savedDeliveryAddress = deliveryAddressRepository.save(deliveryAddress);
        return DeliveryAddressMapper.INSTANCE.toDeliveryAddressDTO(savedDeliveryAddress);
    }

    @Override
    public DeliveryAddressDTO updateDeliveryAddress(int addressId, DeliveryAddressDTO deliveryAddressDTO) {
        if (deliveryAddressRepository.existsById(addressId)) {
            DeliveryAddress deliveryAddress = DeliveryAddressMapper.INSTANCE.toDeliveryAddress(deliveryAddressDTO);
            deliveryAddress.setAddressId(addressId);
            DeliveryAddress updatedDeliveryAddress = deliveryAddressRepository.save(deliveryAddress);
            return DeliveryAddressMapper.INSTANCE.toDeliveryAddressDTO(updatedDeliveryAddress);
        }
        throw new DeliveryAddressNotFoundException("Delivery address not found with id: " + addressId);
    }

    @Override
    public void deleteDeliveryAddress(int addressId) {
        if (deliveryAddressRepository.existsById(addressId)) {
            deliveryAddressRepository.deleteById(addressId);
        } else {
            throw new DeliveryAddressNotFoundException("Delivery address not found with id: " + addressId);
        }
    }
}