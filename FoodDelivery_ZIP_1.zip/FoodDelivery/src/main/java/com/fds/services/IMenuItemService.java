package com.fds.services;

import java.util.List;

import com.fds.dto.MenuItemDTO;

public interface IMenuItemService {
    List<MenuItemDTO> getAllMenuItems();
    MenuItemDTO getMenuItemById(int itemId);
    MenuItemDTO createMenuItem(MenuItemDTO menuItemDTO);
    MenuItemDTO updateMenuItem(int itemId, MenuItemDTO menuItemDTO);
    void deleteMenuItem(int itemId);
}