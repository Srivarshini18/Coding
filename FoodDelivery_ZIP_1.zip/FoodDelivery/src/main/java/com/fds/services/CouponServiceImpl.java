package com.fds.services;

import com.fds.dto.CouponDTO;
import com.fds.entities.Coupon;
import com.fds.exceptions.CouponNotFoundException;
import com.fds.mapper.CouponMapper;
import com.fds.repositories.CouponRepository;
import com.fds.services.ICouponService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CouponServiceImpl implements ICouponService {

    @Autowired
    private CouponRepository couponRepository;

    @Override
    public List<CouponDTO> getAllCoupons() {
        return couponRepository.findAll().stream()
                .map(CouponMapper.INSTANCE::toCouponDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CouponDTO getCouponById(int couponId) {
        return couponRepository.findById(couponId)
                .map(CouponMapper.INSTANCE::toCouponDTO)
                .orElseThrow(() -> new CouponNotFoundException("Coupon not found with id: " + couponId));
    }

    @Override
    public CouponDTO createCoupon(CouponDTO couponDTO) {
        Coupon coupon = CouponMapper.INSTANCE.toCoupon(couponDTO);
        Coupon savedCoupon = couponRepository.save(coupon);
        return CouponMapper.INSTANCE.toCouponDTO(savedCoupon);
    }

    @Override
    public CouponDTO updateCoupon(int couponId, CouponDTO couponDTO) {
        if (couponRepository.existsById(couponId)) {
            Coupon coupon = CouponMapper.INSTANCE.toCoupon(couponDTO);
            coupon.setCouponId(couponId);
            Coupon updatedCoupon = couponRepository.save(coupon);
            return CouponMapper.INSTANCE.toCouponDTO(updatedCoupon);
        }
        throw new CouponNotFoundException("Coupon not found with id: " + couponId);
    }

    @Override
    public void deleteCoupon(int couponId) {
        if (couponRepository.existsById(couponId)) {
            couponRepository.deleteById(couponId);
        } else {
            throw new CouponNotFoundException("Coupon not found with id: " + couponId);
        }
    }
}