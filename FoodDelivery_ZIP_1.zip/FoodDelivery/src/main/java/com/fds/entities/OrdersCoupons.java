package com.fds.entities;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "OrdersCoupons")
public class OrdersCoupons {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne
    @JoinColumn(name = "coupon_id", nullable = false)
    private Coupon coupon;
}
