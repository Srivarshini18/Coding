package com.fds.entities;

import jakarta.persistence.*;
import lombok.Data;
import com.fds.entities.MenuItem;
import com.fds.entities.Order;

@Entity
@Data
@Table(name = "OrderItems")
public class OrderItem {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_item_id")
    private int orderItemId;

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne
    @JoinColumn(name = "item_id", nullable = false)
    private MenuItem menuItem; 

    @Column(name = "quantity")
    private int quantity;
}

 