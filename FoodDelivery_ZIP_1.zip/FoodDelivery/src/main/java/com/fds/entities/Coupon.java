package com.fds.entities;

import java.util.Date;
import java.util.List;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Coupons")
public class Coupon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "coupon_id")
    private int couponId;

    @Column(name = "coupon_code", unique = true)
    private String couponCode;

    @Column(name = "discount_amount")
    private double discountAmount;

    @Column(name = "expiry_date")
    private Date expiryDate;
    
    @OneToMany(mappedBy = "coupon", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrdersCoupons> ordersCoupons;
}