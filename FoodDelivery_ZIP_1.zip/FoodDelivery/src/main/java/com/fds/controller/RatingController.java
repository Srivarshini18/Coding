package com.fds.controller;

import com.fds.dto.RatingDTO;
import com.fds.services.IRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ratings")
public class RatingController {

    @Autowired
    private IRatingService ratingService;

    @GetMapping
    public ResponseEntity<List<RatingDTO>> getAllRatings() {
        List<RatingDTO> ratings = ratingService.getAllRatings();
        return ResponseEntity.ok(ratings);
    }

    @GetMapping("/{ratingId}")
    public ResponseEntity<RatingDTO> getRatingById(@PathVariable int ratingId) {
        RatingDTO rating = ratingService.getRatingById(ratingId);
        if (rating != null) {
            return ResponseEntity.ok(rating);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<RatingDTO> createRating(@RequestBody RatingDTO ratingDTO) {
        RatingDTO createdRating = ratingService.createRating(ratingDTO);
        return ResponseEntity.ok(createdRating);
    }

    @PutMapping("/{ratingId}")
    public ResponseEntity<RatingDTO> updateRating(@PathVariable int ratingId, @RequestBody RatingDTO ratingDTO) {
        RatingDTO updatedRating = ratingService.updateRating(ratingId, ratingDTO);
        if (updatedRating != null) {
            return ResponseEntity.ok(updatedRating);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{ratingId}")
    public ResponseEntity<Void> deleteRating(@PathVariable int ratingId) {
        ratingService.deleteRating(ratingId);
        return ResponseEntity.noContent().build();
    }
}