package com.fds.controller;

import com.fds.dto.*;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.Rating;
import com.fds.services.IRestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/restaurant")
public class RestaurantController {

    @Autowired
    private IRestaurantService restaurantService;

    @GetMapping
    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/{restaurantId}")
    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable int restaurantId) {
        RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
        if (restaurant != null) {
            return ResponseEntity.ok(restaurant);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<RestaurantDTO> createRestaurant(@RequestBody RestaurantDTO restaurantDTO) {
        RestaurantDTO createdRestaurant = restaurantService.createRestaurant(restaurantDTO);
        return ResponseEntity.ok(createdRestaurant);
    }

    @PutMapping("/{restaurantId}")
    public ResponseEntity<RestaurantDTO> updateRestaurant(@PathVariable int restaurantId, @RequestBody RestaurantDTO restaurantDTO) {
        RestaurantDTO updatedRestaurant = restaurantService.updateRestaurant(restaurantId, restaurantDTO);
        if (updatedRestaurant != null) {
            return ResponseEntity.ok(updatedRestaurant);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{restaurantId}")
    public ResponseEntity<Void> deleteRestaurant(@PathVariable int restaurantId) {
        restaurantService.deleteRestaurant(restaurantId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{restaurantId}/menu")
    public ResponseEntity<List<MenuItemDTO>> getMenuItemsByRestaurant(@PathVariable int restaurantId) {
        List<MenuItemDTO> menuItems = restaurantService.getMenuItemsByRestaurant(restaurantId);
        if (menuItems != null) {
            return ResponseEntity.ok(menuItems);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{restaurantId}/reviews")
    public ResponseEntity<List<Rating>> getReviewsByRestaurant(@PathVariable int restaurantId) {
        List<Rating> reviews = restaurantService.getReviewsByRestaurant(restaurantId);
        if (reviews != null) {
            return ResponseEntity.ok(reviews);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{restaurantId}/delivery-areas")
    public ResponseEntity<List<DeliveryAddress>> getDeliveryAreasByRestaurant(@PathVariable int restaurantId) {
        List<DeliveryAddress> deliveryAreas = restaurantService.getDeliveryAreasByRestaurant(restaurantId);
        if (deliveryAreas != null) {
            return ResponseEntity.ok(deliveryAreas);
        }
        return ResponseEntity.notFound().build();
    }
}
