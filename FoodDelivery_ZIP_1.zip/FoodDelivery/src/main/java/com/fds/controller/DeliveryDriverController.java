package com.fds.controller;

import com.fds.dto.DeliveryDriverDTO;
import com.fds.services.IDeliveryDriverService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/delivery-drivers")
public class DeliveryDriverController {

    @Autowired
    private IDeliveryDriverService deliveryDriverService;

    @GetMapping
    public ResponseEntity<List<DeliveryDriverDTO>> getAllDeliveryDrivers() {
        List<DeliveryDriverDTO> deliveryDrivers = deliveryDriverService.getAllDeliveryDrivers();
        return ResponseEntity.ok(deliveryDrivers);
    }

    @GetMapping("/{driverId}")
    public ResponseEntity<DeliveryDriverDTO> getDeliveryDriverById(@PathVariable int driverId) {
        DeliveryDriverDTO deliveryDriver = deliveryDriverService.getDeliveryDriverById(driverId);
        if (deliveryDriver != null) {
            return ResponseEntity.ok(deliveryDriver);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<DeliveryDriverDTO> createDeliveryDriver(@RequestBody DeliveryDriverDTO deliveryDriverDTO) {
        DeliveryDriverDTO createdDeliveryDriver = deliveryDriverService.createDeliveryDriver(deliveryDriverDTO);
        return ResponseEntity.ok(createdDeliveryDriver);
    }

    @PutMapping("/{driverId}")
    public ResponseEntity<DeliveryDriverDTO> updateDeliveryDriver(@PathVariable int driverId, @RequestBody DeliveryDriverDTO deliveryDriverDTO) {
        DeliveryDriverDTO updatedDeliveryDriver = deliveryDriverService.updateDeliveryDriver(driverId, deliveryDriverDTO);
        if (updatedDeliveryDriver != null) {
            return ResponseEntity.ok(updatedDeliveryDriver);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{driverId}")
    public ResponseEntity<Void> deleteDeliveryDriver(@PathVariable int driverId) {
        deliveryDriverService.deleteDeliveryDriver(driverId);
        return ResponseEntity.noContent().build();
    }
}