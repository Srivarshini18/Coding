package com.fds.controller;

import com.fds.dto.DeliveryAddressDTO;
import com.fds.services.IDeliveryAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/delivery-addresses")
public class DeliveryAddressController {

    @Autowired
    private IDeliveryAddressService deliveryAddressService;

    @GetMapping
    public ResponseEntity<List<DeliveryAddressDTO>> getAllDeliveryAddresses() {
        List<DeliveryAddressDTO> deliveryAddresses = deliveryAddressService.getAllDeliveryAddresses();
        return ResponseEntity.ok(deliveryAddresses);
    }

    @GetMapping("/{addressId}")
    public ResponseEntity<DeliveryAddressDTO> getDeliveryAddressById(@PathVariable int addressId) {
        DeliveryAddressDTO deliveryAddress = deliveryAddressService.getDeliveryAddressById(addressId);
        if (deliveryAddress != null) {
            return ResponseEntity.ok(deliveryAddress);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<DeliveryAddressDTO> createDeliveryAddress(@RequestBody DeliveryAddressDTO deliveryAddressDTO) {
        DeliveryAddressDTO createdDeliveryAddress = deliveryAddressService.createDeliveryAddress(deliveryAddressDTO);
        return ResponseEntity.ok(createdDeliveryAddress);
    }

    @PutMapping("/{addressId}")
    public ResponseEntity<DeliveryAddressDTO> updateDeliveryAddress(@PathVariable int addressId, @RequestBody DeliveryAddressDTO deliveryAddressDTO) {
        DeliveryAddressDTO updatedDeliveryAddress = deliveryAddressService.updateDeliveryAddress(addressId, deliveryAddressDTO);
        if (updatedDeliveryAddress != null) {
            return ResponseEntity.ok(updatedDeliveryAddress);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{addressId}")
    public ResponseEntity<Void> deleteDeliveryAddress(@PathVariable int addressId) {
        deliveryAddressService.deleteDeliveryAddress(addressId);
        return ResponseEntity.noContent().build();
    }
}
