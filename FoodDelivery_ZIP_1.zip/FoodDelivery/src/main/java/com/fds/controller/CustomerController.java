package com.fds.controller;

import com.fds.dto.CustomerDTO;
import com.fds.dto.OrderDTO;
import com.fds.entities.Rating;
import com.fds.exceptions.CustomerNotFoundException;
import com.fds.exceptions.NoOrdersFoundException;
import com.fds.exceptions.ResourceNotFoundException;
import com.fds.services.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private ICustomerService customerService;

    @GetMapping("/all")
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        List<CustomerDTO> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

   
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable int id) {
        Optional<CustomerDTO> customer = customerService.getCustomerById(id);
        if (customer.isPresent()) {
            return ResponseEntity.ok(customer.get());
        } else {
            throw new CustomerNotFoundException("Customer not found with id: " + id);
        }
    }

    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
        return ResponseEntity.ok(createdCustomer);
    }

    @PutMapping("/{customerId}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable int customerId, @RequestBody CustomerDTO customerDTO) {
        CustomerDTO updatedCustomer = customerService.updateCustomer(customerId, customerDTO);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{customerId}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable int customerId) {
        customerService.deleteCustomer(customerId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{customerId}/orders")
    public ResponseEntity<?> getOrdersByCustomer(@PathVariable int customerId) {
        try {
            List<OrderDTO> orders = customerService.getOrdersByCustomer(customerId);
            return ResponseEntity.ok(orders);
        } catch (NoOrdersFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
    
    @GetMapping("/{customerId}/reviews")
    public ResponseEntity<List<Rating>> getReviewsByCustomer(@PathVariable int customerId) {
        List<Rating> reviews = customerService.getReviewsByCustomer(customerId);
        if (reviews != null) {
            return ResponseEntity.ok(reviews);
        }
        return ResponseEntity.notFound().build();
    }
}

