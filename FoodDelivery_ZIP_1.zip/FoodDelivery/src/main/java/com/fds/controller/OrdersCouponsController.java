package com.fds.controller;

import com.fds.dto.OrdersCouponsDTO;
import com.fds.services.IOrdersCouponsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orderscoupons")
public class OrdersCouponsController {

    @Autowired
    private IOrdersCouponsService ordersCouponsService;

    @GetMapping
    public ResponseEntity<List<OrdersCouponsDTO>> getAllOrdersCoupons() {
        List<OrdersCouponsDTO> ordersCoupons = ordersCouponsService.getAllOrdersCoupons();
        return ResponseEntity.ok(ordersCoupons);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrdersCouponsDTO> getOrdersCouponsById(@PathVariable int id) {
        OrdersCouponsDTO ordersCoupons = ordersCouponsService.getOrdersCouponsById(id);
        if (ordersCoupons != null) {
            return ResponseEntity.ok(ordersCoupons);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<OrdersCouponsDTO> createOrdersCoupons(@RequestBody OrdersCouponsDTO ordersCouponsDTO) {
        OrdersCouponsDTO createdOrdersCoupons = ordersCouponsService.createOrdersCoupons(ordersCouponsDTO);
        return ResponseEntity.ok(createdOrdersCoupons);
    }

    @PutMapping("/{id}")
    public ResponseEntity<OrdersCouponsDTO> updateOrdersCoupons(@PathVariable int id, @RequestBody OrdersCouponsDTO ordersCouponsDTO) {
        OrdersCouponsDTO updatedOrdersCoupons = ordersCouponsService.updateOrdersCoupons(id, ordersCouponsDTO);
        if (updatedOrdersCoupons != null) {
            return ResponseEntity.ok(updatedOrdersCoupons);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrdersCoupons(@PathVariable int id) {
        ordersCouponsService.deleteOrdersCoupons(id);
        return ResponseEntity.noContent().build();
    }
}