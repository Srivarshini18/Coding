package com.fds.controller;

import com.fds.dto.CouponDTO;
import com.fds.services.ICouponService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coupons")
public class CouponController {

    @Autowired
    private ICouponService couponService;

    @GetMapping
    public ResponseEntity<List<CouponDTO>> getAllCoupons() {
        List<CouponDTO> coupons = couponService.getAllCoupons();
        return ResponseEntity.ok(coupons);
    }

    @GetMapping("/{couponId}")
    public ResponseEntity<CouponDTO> getCouponById(@PathVariable int couponId) {
        CouponDTO coupon = couponService.getCouponById(couponId);
        if (coupon != null) {
            return ResponseEntity.ok(coupon);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<CouponDTO> createCoupon(@RequestBody CouponDTO couponDTO) {
        CouponDTO createdCoupon = couponService.createCoupon(couponDTO);
        return ResponseEntity.ok(createdCoupon);
    }

    @PutMapping("/{couponId}")
    public ResponseEntity<CouponDTO> updateCoupon(@PathVariable int couponId, @RequestBody CouponDTO couponDTO) {
        CouponDTO updatedCoupon = couponService.updateCoupon(couponId, couponDTO);
        if (updatedCoupon != null) {
            return ResponseEntity.ok(updatedCoupon);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{couponId}")
    public ResponseEntity<Void> deleteCoupon(@PathVariable int couponId) {
        couponService.deleteCoupon(couponId);
        return ResponseEntity.noContent().build();
    }
}