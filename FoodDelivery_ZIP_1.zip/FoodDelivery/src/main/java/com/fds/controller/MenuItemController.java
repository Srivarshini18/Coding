package com.fds.controller;

import com.fds.dto.MenuItemDTO;
import com.fds.dto.RestaurantDTO;
import com.fds.entities.Restaurant;
import com.fds.exceptions.RestaurantNotFoundException;
import com.fds.services.IMenuItemService;
import com.fds.services.IRestaurantService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/menuitem")
public class MenuItemController {

    @Autowired
    private IMenuItemService menuItemService;
    
    @Autowired
    private IRestaurantService restaurantService;

    @GetMapping
    public ResponseEntity<List<MenuItemDTO>> getAllMenuItems() {
        List<MenuItemDTO> menuItems = menuItemService.getAllMenuItems();
        return ResponseEntity.ok(menuItems);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<MenuItemDTO> getMenuItemById(@PathVariable int itemId) {
        MenuItemDTO menuItem = menuItemService.getMenuItemById(itemId);
        if (menuItem != null) {
            return ResponseEntity.ok(menuItem);
        }
        return ResponseEntity.notFound().build();
    }
    
    @PostMapping
    public ResponseEntity<MenuItemDTO> createMenuItem(@RequestBody MenuItemDTO menuItemDTO) {
        // This will throw RestaurantNotFoundException if the restaurant is not found
        RestaurantDTO restaurant = restaurantService.getRestaurantById(menuItemDTO.getRestaurantId());
        
        MenuItemDTO createdMenuItem = menuItemService.createMenuItem(menuItemDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdMenuItem);
    }  

    @PutMapping("/{itemId}")
    public ResponseEntity<MenuItemDTO> updateMenuItem(@PathVariable int itemId, @RequestBody MenuItemDTO menuItemDTO) {
        MenuItemDTO updatedMenuItem = menuItemService.updateMenuItem(itemId, menuItemDTO);
        if (updatedMenuItem != null) {
            return ResponseEntity.ok(updatedMenuItem);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteMenuItem(@PathVariable int itemId) {
        menuItemService.deleteMenuItem(itemId);
        return ResponseEntity.noContent().build();
    }
}