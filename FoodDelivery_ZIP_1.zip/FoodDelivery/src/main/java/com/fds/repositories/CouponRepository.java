package com.fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fds.entities.Coupon;

public interface CouponRepository extends JpaRepository<Coupon, Integer> {

}
