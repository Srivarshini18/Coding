package com.fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fds.entities.DeliveryDriver;

public interface DeliveryDriverRepository extends JpaRepository<DeliveryDriver, Integer> {

}
