package com.fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fds.entities.DeliveryAddress;

public interface DeliveryAddressRepository extends JpaRepository<DeliveryAddress, Integer> {

}
