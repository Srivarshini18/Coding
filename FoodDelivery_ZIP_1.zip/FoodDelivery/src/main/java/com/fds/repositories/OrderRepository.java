package com.fds.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fds.entities.DeliveryDriver;
import com.fds.entities.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	List<Order> findByDeliveryDriver(DeliveryDriver deliveryDriver);
}