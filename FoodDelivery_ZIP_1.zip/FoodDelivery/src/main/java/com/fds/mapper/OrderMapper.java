package com.fds.mapper;

import com.fds.dto.OrderDTO;
import com.fds.entities.Order;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OrderMapper {
    OrderMapper INSTANCE = Mappers.getMapper(OrderMapper.class);

    @Mapping(source = "customer.customerId", target = "customerId")
    @Mapping(source = "restaurant.restaurantId", target = "restaurantId")
    @Mapping(source = "deliveryDriver.driverId", target = "deliveryDriverId")
    OrderDTO toOrderDTO(Order order);

    @Mapping(source = "customerId", target = "customer.customerId")
    @Mapping(source = "restaurantId", target = "restaurant.restaurantId")
    @Mapping(source = "deliveryDriverId", target = "deliveryDriver.driverId")
    Order toOrder(OrderDTO orderDTO);
}