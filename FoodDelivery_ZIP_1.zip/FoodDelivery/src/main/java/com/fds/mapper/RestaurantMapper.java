package com.fds.mapper;

import com.fds.dto.RestaurantDTO;
import com.fds.entities.Restaurant;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RestaurantMapper {
    RestaurantMapper INSTANCE = Mappers.getMapper(RestaurantMapper.class);

    RestaurantDTO toRestaurantDTO(Restaurant restaurant);
    Restaurant toRestaurant(RestaurantDTO restaurantDTO);
}