package com.fds.mapper;


import com.fds.dto.MenuItemDTO;
import com.fds.entities.MenuItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MenuItemMapper {
    MenuItemMapper INSTANCE = Mappers.getMapper(MenuItemMapper.class);

    @Mapping(source = "restaurant.restaurantId", target = "restaurantId")
    MenuItemDTO toMenuItemDTO(MenuItem menuItem);

    @Mapping(source = "restaurantId", target = "restaurant.restaurantId")
    MenuItem toMenuItem(MenuItemDTO menuItemDTO);
}