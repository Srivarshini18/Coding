package com.fds.mapper;

import com.fds.dto.DeliveryAddressDTO;
import com.fds.entities.DeliveryAddress;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DeliveryAddressMapper {
    DeliveryAddressMapper INSTANCE = Mappers.getMapper(DeliveryAddressMapper.class);

    @Mapping(source = "customer.customerId", target = "customerId")
    DeliveryAddressDTO toDeliveryAddressDTO(DeliveryAddress deliveryAddress);

    @Mapping(source = "customerId", target = "customer.customerId")
    DeliveryAddress toDeliveryAddress(DeliveryAddressDTO deliveryAddressDTO);
}