package com.fds.mapper;

import com.fds.dto.DeliveryDriverDTO;
import com.fds.entities.DeliveryDriver;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DeliveryDriverMapper {
    DeliveryDriverMapper INSTANCE = Mappers.getMapper(DeliveryDriverMapper.class);

    DeliveryDriverDTO toDeliveryDriverDTO(DeliveryDriver deliveryDriver);
    DeliveryDriver toDeliveryDriver(DeliveryDriverDTO deliveryDriverDTO);
}