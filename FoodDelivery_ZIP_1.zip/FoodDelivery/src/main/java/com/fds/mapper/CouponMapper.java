package com.fds.mapper;

import com.fds.dto.CouponDTO;
import com.fds.entities.Coupon;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CouponMapper {
    CouponMapper INSTANCE = Mappers.getMapper(CouponMapper.class);

    CouponDTO toCouponDTO(Coupon coupon);
    Coupon toCoupon(CouponDTO couponDTO);
}