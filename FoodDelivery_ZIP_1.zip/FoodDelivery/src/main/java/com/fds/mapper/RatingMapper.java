package com.fds.mapper;

import com.fds.dto.RatingDTO;
import com.fds.entities.Rating;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RatingMapper {
    RatingMapper INSTANCE = Mappers.getMapper(RatingMapper.class);

    @Mapping(source = "order.orderId", target = "orderId")
    @Mapping(source = "restaurant.restaurantId", target = "restaurantId")
    RatingDTO toRatingDTO(Rating rating);

    @Mapping(source = "orderId", target = "order.orderId")
    @Mapping(source = "restaurantId", target = "restaurant.restaurantId")
    Rating toRating(RatingDTO ratingDTO);
}