package com.fds.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import com.fds.dto.OrderItemDTO;
import com.fds.entities.OrderItem;

@Mapper
public interface OrderItemMapper {
    OrderItemMapper INSTANCE = Mappers.getMapper(OrderItemMapper.class);

    @Mapping(source = "order.orderId", target = "orderId")
    @Mapping(source = "menuItem.itemId", target = "itemId")
    OrderItemDTO toOrderItemDTO(OrderItem orderItem);

    @Mapping(source = "orderId", target = "order.orderId")
    @Mapping(source = "itemId", target = "menuItem.itemId")
    OrderItem toOrderItem(OrderItemDTO orderItemDTO);
}