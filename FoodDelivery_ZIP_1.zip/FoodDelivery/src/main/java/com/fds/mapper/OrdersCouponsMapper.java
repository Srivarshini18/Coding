package com.fds.mapper;

import com.fds.dto.OrdersCouponsDTO;
import com.fds.entities.OrdersCoupons;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OrdersCouponsMapper {
    OrdersCouponsMapper INSTANCE = Mappers.getMapper(OrdersCouponsMapper.class);

    @Mapping(source = "order.orderId", target = "orderId")
    @Mapping(source = "coupon.couponId", target = "couponId")
    OrdersCouponsDTO toOrdersCouponsDTO(OrdersCoupons ordersCoupons);

    @Mapping(source = "orderId", target = "order.orderId")
    @Mapping(source = "couponId", target = "coupon.couponId")
    OrdersCoupons toOrdersCoupons(OrdersCouponsDTO ordersCouponsDTO);
}