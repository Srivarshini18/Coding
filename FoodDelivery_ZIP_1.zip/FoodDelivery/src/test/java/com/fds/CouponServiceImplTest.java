package com.fds;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fds.dto.CouponDTO;
import com.fds.entities.Coupon;
import com.fds.exceptions.CouponNotFoundException;
import com.fds.mapper.CouponMapper;
import com.fds.repositories.CouponRepository;
import com.fds.services.CouponServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CouponServiceImplTest {

    @Mock
    private CouponRepository couponRepository;

    @InjectMocks
    private CouponServiceImpl couponService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllCoupons() {
        Coupon coupon = new Coupon();
        coupon.setCouponId(1);
        coupon.setCouponCode("SAVE10");
        when(couponRepository.findAll()).thenReturn(Arrays.asList(coupon));

        List<CouponDTO> coupons = couponService.getAllCoupons();
        assertEquals(1, coupons.size());
        assertEquals("SAVE10", coupons.get(0).getCouponCode());
    }

    @Test
    public void testGetCouponById() {
        Coupon coupon = new Coupon();
        coupon.setCouponId(1);
        coupon.setCouponCode("SAVE10");
        when(couponRepository.findById(1)).thenReturn(Optional.of(coupon));

        CouponDTO couponDTO = couponService.getCouponById(1);
        assertNotNull(couponDTO);
        assertEquals("SAVE10", couponDTO.getCouponCode());
    }

    @Test
    public void testGetCouponById_NotFound() {
        when(couponRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(CouponNotFoundException.class, () -> couponService.getCouponById(1));
    }

    @Test
    public void testCreateCoupon() {
        Coupon coupon = new Coupon();
        coupon.setCouponCode("SAVE10");
        when(couponRepository.save(any(Coupon.class))).thenReturn(coupon);

        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setCouponCode("SAVE10");
        CouponDTO createdCoupon = couponService.createCoupon(couponDTO);

        assertNotNull(createdCoupon);
        assertEquals("SAVE10", createdCoupon.getCouponCode());
    }

    @Test
    public void testUpdateCoupon() {
        Coupon coupon = new Coupon();
        coupon.setCouponId(1);
        coupon.setCouponCode("SAVE10");
        when(couponRepository.existsById(1)).thenReturn(true);
        when(couponRepository.save(any(Coupon.class))).thenReturn(coupon);

        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setCouponCode("SAVE10");
        CouponDTO updatedCoupon = couponService.updateCoupon(1, couponDTO);

        assertNotNull(updatedCoupon);
        assertEquals("SAVE10", updatedCoupon.getCouponCode());
    }

    @Test
    public void testUpdateCoupon_NotFound() {
        when(couponRepository.existsById(1)).thenReturn(false);

        CouponDTO couponDTO = new CouponDTO();
        assertThrows(CouponNotFoundException.class, () -> couponService.updateCoupon(1, couponDTO));
    }

    @Test
    public void testDeleteCoupon() {
        when(couponRepository.existsById(1)).thenReturn(true);

        couponService.deleteCoupon(1);
        verify(couponRepository, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteCoupon_NotFound() {
        when(couponRepository.existsById(1)).thenReturn(false);

        assertThrows(CouponNotFoundException.class, () -> couponService.deleteCoupon(1));
    }
}