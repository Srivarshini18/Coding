package com.fds;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fds.dto.OrderDTO;
import com.fds.entities.Order;
import com.fds.entities.DeliveryDriver;
import com.fds.exceptions.OrderNotFoundException;
import com.fds.exceptions.DeliveryDriverNotFoundException;
import com.fds.mapper.OrderMapper;
import com.fds.repositories.OrderRepository;
import com.fds.repositories.DeliveryDriverRepository;
import com.fds.services.OrderServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OrderServiceImplTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private DeliveryDriverRepository driverRepository;

    @InjectMocks
    private OrderServiceImpl orderService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllOrders() {
        Order order = new Order();
        order.setOrderId(1);
        when(orderRepository.findAll()).thenReturn(Arrays.asList(order));

        List<OrderDTO> orders = orderService.getAllOrders();
        assertEquals(1, orders.size());
        assertEquals(1, orders.get(0).getOrderId());
    }

    @Test
    public void testGetOrderById() {
        Order order = new Order();
        order.setOrderId(1);
        when(orderRepository.findById(1)).thenReturn(Optional.of(order));

        OrderDTO orderDTO = orderService.getOrderById(1);
        assertNotNull(orderDTO);
        assertEquals(1, orderDTO.getOrderId());
    }

    @Test
    public void testGetOrderById_NotFound() {
        when(orderRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(OrderNotFoundException.class, () -> orderService.getOrderById(1));
    }

    @Test
    public void testCreateOrder() {
        Order order = new Order();
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderDTO orderDTO = new OrderDTO();
        OrderDTO createdOrder = orderService.createOrder(orderDTO);

        assertNotNull(createdOrder);
    }

    @Test
    public void testUpdateOrder() {
        Order order = new Order();
        order.setOrderId(1);
        when(orderRepository.existsById(1)).thenReturn(true);
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderDTO orderDTO = new OrderDTO();
        OrderDTO updatedOrder = orderService.updateOrder(1, orderDTO);

        assertNotNull(updatedOrder);
        assertEquals(1, updatedOrder.getOrderId());
    }

    @Test
    public void testUpdateOrder_NotFound() {
        when(orderRepository.existsById(1)).thenReturn(false);

        OrderDTO orderDTO = new OrderDTO();
        assertThrows(OrderNotFoundException.class, () -> orderService.updateOrder(1, orderDTO));
    }

    @Test
    public void testAssignDriver() {
        Order order = new Order();
        order.setOrderId(1);
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        when(orderRepository.findById(1)).thenReturn(Optional.of(order));
        when(driverRepository.findById(1)).thenReturn(Optional.of(driver));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderDTO assignedOrder = orderService.assignDriver(1, 1);

        assertNotNull(assignedOrder);
        assertEquals(1, assignedOrder.getOrderId());
    }

    @Test
    public void testAssignDriver_OrderNotFound() {
        when(orderRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(OrderNotFoundException.class, () -> orderService.assignDriver(1, 1));
    }

    @Test
    public void testAssignDriver_DriverNotFound() {
        Order order = new Order();
        order.setOrderId(1);
        when(orderRepository.findById(1)).thenReturn(Optional.of(order));
        when(driverRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(DeliveryDriverNotFoundException.class, () -> orderService.assignDriver(1, 1));
    }

    @Test
    public void testDeleteOrder() {
        when(orderRepository.existsById(1)).thenReturn(true);

        orderService.deleteOrder(1);
        verify(orderRepository, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteOrder_NotFound() {
        when(orderRepository.existsById(1)).thenReturn(false);

        assertThrows(OrderNotFoundException.class, () -> orderService.deleteOrder(1));
    }
}