package com.fds;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fds.dto.RestaurantDTO;
import com.fds.entities.Restaurant;
import com.fds.exceptions.RestaurantNotFoundException;
import com.fds.mapper.RestaurantMapper;
import com.fds.repositories.RestaurantRepository;
import com.fds.services.RestaurantServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class RestaurantServiceImplTest {

    @Mock
    private RestaurantRepository restaurantRepository;

    @InjectMocks
    private RestaurantServiceImpl restaurantService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllRestaurants() {
        Restaurant restaurant = new Restaurant();
        restaurant.setRestaurantId(1);
        restaurant.setRestaurantName("Test Restaurant");
        when(restaurantRepository.findAll()).thenReturn(Arrays.asList(restaurant));

        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
        assertEquals(1, restaurants.size());
        assertEquals("Test Restaurant", restaurants.get(0).getRestaurantName());
    }

    @Test
    public void testGetRestaurantById() {
        Restaurant restaurant = new Restaurant();
        restaurant.setRestaurantId(1);
        restaurant.setRestaurantName("Test Restaurant");
        when(restaurantRepository.findById(1)).thenReturn(Optional.of(restaurant));

        RestaurantDTO restaurantDTO = restaurantService.getRestaurantById(1);
        assertNotNull(restaurantDTO);
        assertEquals("Test Restaurant", restaurantDTO.getRestaurantName());
    }

    @Test
    public void testGetRestaurantById_NotFound() {
        when(restaurantRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(RestaurantNotFoundException.class, () -> restaurantService.getRestaurantById(1));
    }

    @Test
    public void testCreateRestaurant() {
        Restaurant restaurant = new Restaurant();
        restaurant.setRestaurantName("Test Restaurant");
        when(restaurantRepository.save(any(Restaurant.class))).thenReturn(restaurant);

        RestaurantDTO restaurantDTO = new RestaurantDTO();
        restaurantDTO.setRestaurantName("Test Restaurant");
        RestaurantDTO createdRestaurant = restaurantService.createRestaurant(restaurantDTO);

        assertNotNull(createdRestaurant);
        assertEquals("Test Restaurant", createdRestaurant.getRestaurantName());
    }

    @Test
    public void testUpdateRestaurant() {
        Restaurant restaurant = new Restaurant();
        restaurant.setRestaurantId(1);
        restaurant.setRestaurantName("Test Restaurant");
        when(restaurantRepository.existsById(1)).thenReturn(true);
        when(restaurantRepository.save(any(Restaurant.class))).thenReturn(restaurant);

        RestaurantDTO restaurantDTO = new RestaurantDTO();
        restaurantDTO.setRestaurantName("Test Restaurant");
        RestaurantDTO updatedRestaurant = restaurantService.updateRestaurant(1, restaurantDTO);

        assertNotNull(updatedRestaurant);
        assertEquals("Test Restaurant", updatedRestaurant.getRestaurantName());
    }

    @Test
    public void testUpdateRestaurant_NotFound() {
        when(restaurantRepository.existsById(1)).thenReturn(false);

        RestaurantDTO restaurantDTO = new RestaurantDTO();
        assertThrows(RestaurantNotFoundException.class, () -> restaurantService.updateRestaurant(1, restaurantDTO));
    }

    @Test
    public void testDeleteRestaurant() {
        when(restaurantRepository.existsById(1)).thenReturn(true);

        restaurantService.deleteRestaurant(1);
        verify(restaurantRepository, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteRestaurant_NotFound() {
        when(restaurantRepository.existsById(1)).thenReturn(false);

        assertThrows(RestaurantNotFoundException.class, () -> restaurantService.deleteRestaurant(1));
    }
}