package com.fds;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fds.dto.CustomerDTO;
import com.fds.entities.Customer;
import com.fds.exceptions.CustomerNotFoundException;
import com.fds.mapper.CustomerMapper;
import com.fds.repositories.CustomerRepository;
import com.fds.services.CustomerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllCustomers() {
        Customer customer = new Customer();
        customer.setCustomerId(1);
        customer.setCustomerName("John Doe");
        when(customerRepository.findAll()).thenReturn(Arrays.asList(customer));

        List<CustomerDTO> customers = customerService.getAllCustomers();
        assertEquals(1, customers.size());
        assertEquals("John Doe", customers.get(0).getCustomerName());
    }

    @Test
    public void testGetCustomerById() {
        Customer customer = new Customer();
        customer.setCustomerId(1);
        customer.setCustomerName("John Doe");
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));

        CustomerDTO customerDTO = customerService.getCustomerById(1).orElse(null);
        assertNotNull(customerDTO);
        assertEquals("John Doe", customerDTO.getCustomerName());
    }

    @Test
    public void testGetCustomerById_NotFound() {
        when(customerRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomerById(1));
    }

    @Test
    public void testCreateCustomer() {
        Customer customer = new Customer();
        customer.setCustomerName("John Doe");
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerName("John Doe");
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);

        assertNotNull(createdCustomer);
        assertEquals("John Doe", createdCustomer.getCustomerName());
    }

    @Test
    public void testUpdateCustomer() {
        Customer customer = new Customer();
        customer.setCustomerId(1);
        customer.setCustomerName("John Doe");
        when(customerRepository.existsById(1)).thenReturn(true);
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerName("John Doe");
        CustomerDTO updatedCustomer = customerService.updateCustomer(1, customerDTO);

        assertNotNull(updatedCustomer);
        assertEquals("John Doe", updatedCustomer.getCustomerName());
    }

    @Test
    public void testUpdateCustomer_NotFound() {
        when(customerRepository.existsById(1)).thenReturn(false);

        CustomerDTO customerDTO = new CustomerDTO();
        assertThrows(CustomerNotFoundException.class, () -> customerService.updateCustomer(1, customerDTO));
    }

    @Test
    public void testDeleteCustomer() {
        when(customerRepository.existsById(1)).thenReturn(true);

        customerService.deleteCustomer(1);
        verify(customerRepository, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteCustomer_NotFound() {
        when(customerRepository.existsById(1)).thenReturn(false);

        assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomer(1));
    }
}












//package com.fds;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import com.fds.dto.CustomerDTO;
//import com.fds.dto.OrderDTO;
//import com.fds.entities.Customer;
//import com.fds.entities.Rating;
//import com.fds.exceptions.CustomerNotFoundException;
//import com.fds.exceptions.NoOrdersFoundException;
//import com.fds.exceptions.NoReviewsFoundException;
//import com.fds.mapper.CustomerMapper;
//import com.fds.mapper.OrderMapper;
//import com.fds.repositories.CustomerRepository;
//import com.fds.services.CustomerServiceImpl;
//
//import jakarta.persistence.criteria.Order;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//public class CustomerServiceImplTest {
//
//    @Mock
//    private CustomerRepository customerRepository;
//
//    @Mock
//    private OrderMapper orderMapper;
//    
//    @InjectMocks
//    private CustomerServiceImpl customerService;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//        when(orderMapper.toOrderDTO(any(Order.class))).thenReturn(new OrderDTO());
//    }
//
//    @Test
//    public void testGetAllCustomers() {
//        Customer customer = new Customer();
//        customer.setCustomerId(1);
//        when(customerRepository.findAll()).thenReturn(Arrays.asList(customer));
//
//        List<CustomerDTO> customers = customerService.getAllCustomers();
//        assertEquals(1, customers.size());
//        verify(customerRepository, times(1)).findAll();
//    }
//
//    @Test
//    public void testGetCustomerById() {
//        Customer customer = new Customer();
//        customer.setCustomerId(1);
//        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
//
//        Optional<CustomerDTO> customerDTO = customerService.getCustomerById(1);
//        assertTrue(customerDTO.isPresent());
//        verify(customerRepository, times(1)).findById(1);
//    }
//
//    @Test
//    public void testGetCustomerByIdNotFound() {
//        when(customerRepository.findById(1)).thenReturn(Optional.empty());
//
//        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomerById(1));
//        verify(customerRepository, times(1)).findById(1);
//    }
//
//    @Test
//    public void testCreateCustomer() {
//        Customer customer = new Customer();
//        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
//
//        CustomerDTO customerDTO = new CustomerDTO();
//        CustomerDTO savedCustomer = customerService.createCustomer(customerDTO);
//        assertNotNull(savedCustomer);
//        verify(customerRepository, times(1)).save(any(Customer.class));
//    }
//
//    @Test
//    public void testUpdateCustomer() {
//        Customer customer = new Customer();
//        when(customerRepository.existsById(1)).thenReturn(true);
//        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
//
//        CustomerDTO customerDTO = new CustomerDTO();
//        CustomerDTO updatedCustomer = customerService.updateCustomer(1, customerDTO);
//        assertNotNull(updatedCustomer);
//        verify(customerRepository, times(1)).existsById(1);
//        verify(customerRepository, times(1)).save(any(Customer.class));
//    }
//
//    @Test
//    public void testUpdateCustomerNotFound() {
//        when(customerRepository.existsById(1)).thenReturn(false);
//
//        CustomerDTO customerDTO = new CustomerDTO();
//        assertThrows(CustomerNotFoundException.class, () -> customerService.updateCustomer(1, customerDTO));
//        verify(customerRepository, times(1)).existsById(1);
//    }
//
//    @Test
//    public void testDeleteCustomer() {
//        when(customerRepository.existsById(1)).thenReturn(true);
//
//        customerService.deleteCustomer(1);
//        verify(customerRepository, times(1)).existsById(1);
//        verify(customerRepository, times(1)).deleteById(1);
//    }
//
//    @Test
//    public void testDeleteCustomerNotFound() {
//        when(customerRepository.existsById(1)).thenReturn(false);
//
//        assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomer(1));
//        verify(customerRepository, times(1)).existsById(1);
//    }
//
//    @Test
//    public void testGetOrdersByCustomer() {
//        Customer customer = new Customer();
//        customer.setCustomerId(1);
//        
//        Order order = new Order();
//        order.setOrderId(1);
//        order.setOrderDate(LocalDateTime.now());
//        order.setOrderStatus("Pending");
//        order.setCustomer(customer);
//        // Set other necessary fields for Order        
//        customer.setOrders(Arrays.asList(order));
//        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
//        List<OrderDTO> orders = customerService.getOrdersByCustomer(1);
//        assertNotNull(orders);
//        assertEquals(1, orders.size());
//        verify(customerRepository, times(1)).findById(1);
//    }
//
//    @Test
//    public void testGetOrdersByCustomerNotFound() {
//        when(customerRepository.findById(1)).thenReturn(Optional.empty());
//
//        assertThrows(CustomerNotFoundException.class, () -> customerService.getOrdersByCustomer(1));
//        verify(customerRepository, times(1)).findById(1);
//    }
//
//    @Test
//    public void testGetReviewsByCustomer() {
//        Customer customer = new Customer();
//        customer.setCustomerId(1);
//        Rating rating = new Rating();
//        customer.setRatings(Arrays.asList(rating));
//        
//        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
//
//        List<Rating> ratings = customerService.getReviewsByCustomer(1);
//        assertNotNull(ratings);
//        assertEquals(1, ratings.size());
//        verify(customerRepository, times(1)).findById(1);
//    }
//
//    @Test
//    public void testGetReviewsByCustomerNotFound() {
//        when(customerRepository.findById(1)).thenReturn(Optional.empty());
//
//        assertThrows(CustomerNotFoundException.class, () -> customerService.getReviewsByCustomer(1));
//        verify(customerRepository, times(1)).findById(1);
//    }
//}
