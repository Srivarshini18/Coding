package com.fds;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fds.dto.DeliveryDriverDTO;
import com.fds.entities.DeliveryAddress;
import com.fds.entities.DeliveryDriver;
import com.fds.entities.Order;
import com.fds.exceptions.DeliveryDriverNotFoundException;
import com.fds.mapper.DeliveryDriverMapper;
import com.fds.repositories.DeliveryDriverRepository;
import com.fds.repositories.OrderRepository;
import com.fds.services.DeliveryDriverServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class DeliveryDriverServiceImplTest {

    @Mock
    private DeliveryDriverRepository deliveryDriverRepository;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private DeliveryDriverServiceImpl deliveryDriverService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllDeliveryDrivers() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        driver.setDriverName("John Doe");
        when(deliveryDriverRepository.findAll()).thenReturn(Arrays.asList(driver));

        List<DeliveryDriverDTO> drivers = deliveryDriverService.getAllDeliveryDrivers();
        assertEquals(1, drivers.size());
        assertEquals("John Doe", drivers.get(0).getDriverName());
    }

    @Test
    public void testGetDeliveryDriverById() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        driver.setDriverName("John Doe");
        when(deliveryDriverRepository.findById(1)).thenReturn(Optional.of(driver));

        DeliveryDriverDTO driverDTO = deliveryDriverService.getDeliveryDriverById(1);
        assertNotNull(driverDTO);
        assertEquals("John Doe", driverDTO.getDriverName());
    }

    @Test
    public void testCreateDeliveryDriver() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        driver.setDriverName("John Doe");
        DeliveryDriverDTO driverDTO = DeliveryDriverMapper.INSTANCE.toDeliveryDriverDTO(driver);
        when(deliveryDriverRepository.save(any(DeliveryDriver.class))).thenReturn(driver);

        DeliveryDriverDTO savedDriverDTO = deliveryDriverService.createDeliveryDriver(driverDTO);
        assertNotNull(savedDriverDTO);
        assertEquals("John Doe", savedDriverDTO.getDriverName());
    }

    @Test
    public void testUpdateDeliveryDriver() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        driver.setDriverName("John Doe");
        DeliveryDriverDTO driverDTO = DeliveryDriverMapper.INSTANCE.toDeliveryDriverDTO(driver);
        when(deliveryDriverRepository.existsById(1)).thenReturn(true);
        when(deliveryDriverRepository.save(any(DeliveryDriver.class))).thenReturn(driver);

        DeliveryDriverDTO updatedDriverDTO = deliveryDriverService.updateDeliveryDriver(1, driverDTO);
        assertNotNull(updatedDriverDTO);
        assertEquals("John Doe", updatedDriverDTO.getDriverName());
    }

    @Test
    public void testDeleteDeliveryDriver() {
        when(deliveryDriverRepository.existsById(1)).thenReturn(true);
        doNothing().when(deliveryDriverRepository).deleteById(1);

        deliveryDriverService.deleteDeliveryDriver(1);
        verify(deliveryDriverRepository, times(1)).deleteById(1);
    }

    @Test
    public void testAssignDriverToOrder() {
        Order order = new Order();
        order.setOrderId(1);
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        when(orderRepository.findById(1)).thenReturn(Optional.of(order));
        when(deliveryDriverRepository.findById(1)).thenReturn(Optional.of(driver));

        deliveryDriverService.assignDriverToOrder(1, 1);
        assertEquals(driver, order.getDeliveryDriver());
        verify(orderRepository, times(1)).save(order);
    }

    @Test
    public void testUpdateDriverLocation() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);
        when(deliveryDriverRepository.findById(1)).thenReturn(Optional.of(driver));
        when(orderRepository.findByDeliveryDriver(driver)).thenReturn(Arrays.asList(new Order()));

        deliveryDriverService.updateDriverLocation(1, new DeliveryAddress());
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    public void testGetOrdersByDriverId() {
        DeliveryDriver driver = new DeliveryDriver();
        driver.setDriverId(1);

        Order order1 = new Order();
        order1.setOrderId(1);
        order1.setDeliveryDriver(driver);

        Order order2 = new Order();
        order2.setOrderId(2);
        order2.setDeliveryDriver(driver);

        driver.setOrders(Arrays.asList(order1, order2));

        when(deliveryDriverRepository.findById(1)).thenReturn(Optional.of(driver));

        List<Order> orders = deliveryDriverService.getOrdersByDriverId(1);
        assertNotNull(orders);
        assertEquals(2, orders.size());
        assertEquals(1, orders.get(0).getOrderId());
        assertEquals(2, orders.get(1).getOrderId());
    }
}